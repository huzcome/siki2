﻿using UnityEngine;
using System.Collections;

//物品基类
public class Item
{
    public int ID { get; set; }                //ID
    public string Name { get; set; }           //名字
    public ItemType Type { get; set; }         //类型
    public ItemQuality Quality { get; set; }   //品质
    public string Description { get; set; }    //
    public int Capacity { get; set; }          //数量
    public int BuyPrice { get; set; }
    public int SellPrice { get; set; }
    public string Sprite { get; set; }          //显示图片名称


    public Item()
    {
        this.ID = -1;
    }

    //新建与赋值
    public Item(int id, string name, ItemType type, ItemQuality quality, string des, int capacity, int buyPrice, int sellPrice, string sprite)
    {
        this.ID = id;
        this.Name = name;
        this.Type = type;
        this.Quality = quality;
        this.Description = des;
        this.Capacity = capacity;
        this.BuyPrice = buyPrice;
        this.SellPrice = sellPrice;
        this.Sprite = sprite;
    }

    //物品类型
    public enum ItemType
    {
        Consumable,//消耗品
        Equipment, //装备
        Weapon,    //武器
        Material   //材质
    }

    //品质
    public enum ItemQuality
    {
        Common,
        Uncommon,
        Rare,
        Epic,
        Legendary,
        Artifact
    }

    //得到提示面板应该显示什么样的内容
    public virtual string GetToolTipText()
    {
        string color = "";
        switch (Quality)
        {
            case ItemQuality.Common:
                color = "white";
                break;
            case ItemQuality.Uncommon:
                color = "lime";
                break;
            case ItemQuality.Rare:
                color = "navy";
                break;
            case ItemQuality.Epic:
                color = "magenta";
                break;
            case ItemQuality.Legendary:
                color = "orange";
                break;
            case ItemQuality.Artifact:
                color = "red";
                break;
        }
        string text = string.Format("<color={4}>{0}</color>\n<size=10><color=green>购买价格：{1} 出售价格：{2}</color></size>\n<color=yellow><size=10>{3}</size></color>", Name, BuyPrice, SellPrice, Description, color);
        return text;
    }
}
