﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

//工具提示 鼠标移动到物品上 会显示信息
public class ToolTip : MonoBehaviour
{
    private Text toolTipText; //显示的文字
    private Text contentText; //控制显示框的文字
    private CanvasGroup canvasGroup;

    private float targetAlpha = 0;//显隐数值
    public float smoothing = 1;   //动画过度

    void Start()
    {
        toolTipText = GetComponent<Text>();
        contentText = transform.Find("Content").GetComponent<Text>();
        canvasGroup = GetComponent<CanvasGroup>();
    }

    void Update()
    {
        //动画显示
        if (canvasGroup.alpha != targetAlpha)
        {
            canvasGroup.alpha = Mathf.Lerp(canvasGroup.alpha, targetAlpha, smoothing * Time.deltaTime);
            if (Mathf.Abs(canvasGroup.alpha - targetAlpha) < 0.01f)
            {
                canvasGroup.alpha = targetAlpha;
            }
        }
    }

    //显示
    public void Show(string text)
    {
        toolTipText.text = text;
        contentText.text = text;
        targetAlpha = 1;
    }

    //隐藏
    public void Hide()
    {
        targetAlpha = 0;
    }

    //设定位置
    public void SetLocalPotion(Vector3 position)
    {
        transform.localPosition = position;
    }
}
